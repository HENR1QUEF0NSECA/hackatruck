//
//  matchPointApp.swift
//  matchPoint
//
//  Created by Student12 on 18/08/23.
//

import SwiftUI

@main
struct matchPointApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView().preferredColorScheme(.light)
        }
    }
}
